load('vertx.js');

// Constants
var PORT   = 9080;
var WEBAPP = 'webapp/';

// Logger
var logger = vertx.logger;

// Service namespace
var Service = {

	getPosts: function() {
		return [
			{code: 'vertx'    , title: 'Vert.x'   , date: new Date(2013, 1, 25), author: 'Abdelhakim Bachar', nbComments:2 , text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eu justo quam, gravida pharetra urna. Etiam...'},
			{code: 'angularjs', title: 'AngularJS', date: new Date(2012, 10, 2), author: 'Abdelhakim Bachar', nbComments:12, text: 'Vivamus eros neque, elementum non venenatis pharetra, volutpat et ante. Pellentesque et orci turpis, nec vulputate orci. In hac...'},
			{code: 'jquery'   , title: 'jQuery'   , date: new Date(2010, 5, 10), author: 'Abdelhakim Bachar', nbComments:20, text: 'Integer eros arcu, sodales ut euismod in, hendrerit vel magna. Quisque condimentum, libero vel ultricies...'},
		];
	},

	getPost: function(code) {
		logger.info('Chargement du post ayant le code : ' + code);
		return {
			code  : 'vertx'    , 
			title : 'Vert.x'   , 
			date  : new Date(2013, 1, 25), 
			author: 'Abdelhakim Bachar', 
			text  : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eu justo quam, gravida pharetra urna. Etiam lacinia massa quis nisi pharetra id iaculis arcu gravida. Phasellus a odio quam, sed tincidunt metus. Duis hendrerit sodales sapien eget cursus. Suspendisse potenti. Cras orci libero, luctus in sodales ac, sagittis eu lectus. Maecenas commodo libero non leo bibendum lobortis. Nunc tristique scelerisque ligula eget venenatis. Etiam sed ante nisl. Sed elit nunc, dictum vel convallis et, vulputate ac neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. '
		};
	},

	getComments: function(code) {
		logger.info('Chargement des commentaire du post ayant le code : ' + code);
		return [
			{date: new Date(2013, 1, 25), author: 'Abdelhakim Bachar', subject: 'Lorem ipsum dolor sit amet', text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eu justo quam, gravida pharetra urna.'},
			{date: new Date(2013, 1, 26), author: 'Ilyas', subject: 'Vivamus eros neque', text: 'Vivamus eros neque, elementum non venenatis pharetra, volutpat et ante. Pellentesque et orci turpis, nec vulputate orci.'}
		];
	},

	saveComment: function(comment) {
		logger.info('Sauvegarde du commentaire : ' + JSON.stringify(comment));
	}
};



// Création d'un serveur HTTP
vertx.createHttpServer().requestHandler(function(request) {

	logger.info('Traitement de la requête : ' + request.path);

	// Assets
	if (request.path.indexOf('/assets') == 0) {
		request.response.sendFile(WEBAPP + request.path);
	}

	// Partials
	else if (request.path.indexOf('/partials') == 0) {
		request.response.sendFile(WEBAPP + request.path);
	}

	// index.html
	else if (request.path === '/') {
		request.response.sendFile(WEBAPP + 'index.html');
	}

	// Requêtes ajax
	else if (request.path.indexOf('/ajax') == 0) {

		// La liste des posts
		if (request.path == '/ajax/posts.json') {
			var posts = Service.getPosts();
			request.response.end(JSON.stringify(posts));
		}

		// Detail d'un post
		else  if (request.path == '/ajax/post.json') {
			var post   = Service.getPost(request.params().code);
			request.response.end(JSON.stringify(post));
		}

		// List des commentaires
		else if (request.path == '/ajax/comments.json') {
			var comments = Service.getComments(request.params().code);
			request.response.end(JSON.stringify(comments));
		}

		// Sauvegarde d'un commentaire
		else if (request.path == '/ajax/save_comment.json') {

			// Le données du formulaire sont dans le body
			request.dataHandler(function(buffer) {
				Service.saveComment(JSON.parse(buffer).comment);
				request.response.end();
			});
		}

		// Requête inconnues
		else {
			request.response.statusCode = 404;
			request.response.end();
		}
	}

	// Requête inconnues
	else {
		request.response.statusCode = 404;
		request.response.end();
	}

}).listen(PORT);
logger.info('Serveur démarré sur le port ' + PORT);