var app = angular.module('app', []);

/**
 * Configure routes
 */
app.config(['$routeProvider', function($routeProvider) {

	$routeProvider.
		when('/post/:code', {templateUrl:'partials/post.html' , controller: detailPostController}).
		when('/'          , {templateUrl:'partials/posts.html', controller: listPostController}).
		otherwise({redirectTo:'/'});
}]);

/**
 *
 */
function listPostController($scope, $http) {

	$http.get('/ajax/posts.json').success(function(data) {
		$scope.posts = data;
    });
}

/**
 *
 */
function detailPostController($scope, $routeParams, $http) {

	var post_code = $routeParams.code;

	$http({url: '/ajax/post.json', method: "GET", params: {code: post_code}}).success(function(data) {
		$scope.post = data;
    });

	$http({url: '/ajax/comments.json', method: "GET", params: {code: post_code}}).success(function(data) {
		$scope.comments = data;
    });

    //
	$scope.success   = false;
	$scope.httpError = false;
    $scope.sendComment = function() {
    	$http.post('/ajax/save_comment.json', { comment: $scope.comment }).success(function(data) {
			$scope.success = true;
			$scope.comment = {};
		}).error(function(data) {
			$scope.httpError = true;
		});
    }
}