var app = angular.module('app', []);

/**
 * Configure routes
 */
app.config(['$routeProvider', function($routeProvider) {

	$routeProvider.
		when('/post/:code', {templateUrl:'partials/post.html' , controller: detailPostController}).
		when('/'          , {templateUrl:'partials/posts.html', controller: listPostController}).
		otherwise({redirectTo:'/'});
}]);

/**
 *
 */
function listPostController($scope, $http) {

	$http.get('/ajax/posts.json').success(function(data) {
		$scope.posts = data;
    });
}

/**
 *
 */
function detailPostController($scope, $routeParams, $http) {

	$scope.postCode = $routeParams.code;

	$http({url: '/ajax/post.json', method: "GET", params: {code: $scope.postCode}}).success(function(data) {
		$scope.post = data;
    });

	$http({url: '/ajax/comments.json', method: "GET", params: {code: $scope.postCode}}).success(function(data) {
		$scope.comments = data;
    });

    //
	$scope.httpError = false;
    $scope.sendComment = function() {
    	$http.post('/ajax/save_comment.json', {code: $scope.postCode, comment: $scope.comment}).success(function(data) {
    		// Cacher la ligne d'erreur
			$scope.httpError = false;
			// Vider le formulaire
			$scope.comment = {};
			// Ajout du commentaire à la liste des commantaire
			$scope.comments.push(data);
		}).error(function(data) {
			// Afficher la ligne d'erreur
			$scope.httpError = true;
		});
    }
}