load('vertx.js');

// Constants
var PORT   = 9080;
var WEBAPP = 'webapp/';

// Vert.x event bus
var eb = vertx.eventBus;
var pa = 'vertx.mongopersistor';

// Logger
var logger = vertx.logger;

// Service namespace
var Service = {

	getPosts: function(handler) {
		logger.info('Chargement de la liste des posts');

		eb.send(pa, {action: 'find', collection: 'posts', matcher: {}, sort: {title: 1}}, function(reply) {
			handler(reply);
		});
	},

	getPost: function(code, handler) {
		logger.info('Chargement du post ayant le code : ' + code);

		eb.send(pa, {action: 'findone', collection: 'posts', matcher: {code: code}}, function(reply) {
			handler(reply);
		});
	},

	getComments: function(code, handler) {
		logger.info('Chargement des commentaire du post ayant le code : ' + code);

		eb.send(pa, {action: 'findone', collection: 'posts', matcher: {code: code}}, function(reply) {
			handler(reply);
		});
	},

	saveComment: function(code, comment, handler) {
		comment.date = new Date();
		logger.info('Sauvegarde du commentaire : ' + JSON.stringify(comment));

		eb.send(pa, {action: 'update', collection: 'posts', criteria: {code: code}, objNew: {$push: {comments: comment}} /*, upsert: false, multi: false */}, function(reply) {
			handler(comment);
		});
	}
};

// Start a MongoDB persistor module
vertx.deployModule('vertx.mongo-persistor-v1.2', {
    'address': pa,
    'host'   : 'localhost',
    'port'   : 27017,
    'db_name': 'blog_db'
});

// Création d'un serveur HTTP
vertx.createHttpServer().requestHandler(function(request) {

	logger.info('Traitement de la requête : ' + request.path);

	// Assets
	if (request.path.indexOf('/assets') == 0) {
		request.response.sendFile(WEBAPP + request.path);
	}

	// Partials
	else if (request.path.indexOf('/partials') == 0) {
		request.response.sendFile(WEBAPP + request.path);
	}

	// index.html
	else if (request.path === '/') {
		request.response.sendFile(WEBAPP + 'index.html');
	}

	// Requêtes ajax
	else if (request.path.indexOf('/ajax') == 0) {

		// La liste des posts
		if (request.path == '/ajax/posts.json') {
			Service.getPosts(function(reply) {
				var posts    = reply.results;
				var response = new Array();

				for (var i = 0; i < posts.length; i++) {
					response[i] = {
						code      : posts[i].code,
						title     : posts[i].title,
						date      : posts[i].date.$date,
						author    : posts[i].author,
						nbComments: posts[i].comments.length,
						text      : posts[i].text.substr(0, 120) + (posts[i].text.length > 120 ? '...' : '')
					}
				}

				request.response.end(JSON.stringify(response));
			});
		}

		// Detail d'un post
		else  if (request.path == '/ajax/post.json') {
			Service.getPost(request.params().code, function(reply) {
				var post     = reply.result;
				var response = {
					code  : post.code,
					title : post.title,
					date  : post.date.$date,
					author: post.author,
					text  : post.text
				};

				request.response.end(JSON.stringify(response));
			});
		}

		// List des commentaires
		else if (request.path == '/ajax/comments.json') {
			Service.getComments(request.params().code, function(reply) {
				var comments = reply.result.comments;
				var response = new Array();

				for (var i = 0; i < comments.length; i++) {
					response[i] = {
						author  : comments[i].author,
						subject : comments[i].subject,
						date    : comments[i].date.$date,
						text    : comments[i].text
					}
				}

				request.response.end(JSON.stringify(response));
			});
		}

		// Sauvegarde d'un commentaire
		else if (request.path == '/ajax/save_comment.json') {

			// Le données du formulaire sont dans le body
			request.dataHandler(function(buffer) {
				var data = JSON.parse(buffer);
				Service.saveComment(data.code, data.comment, function(comment) {
					request.response.end(JSON.stringify(comment));
				});
			});
		}

		// Requête inconnues
		else {
			request.response.statusCode = 404;
			request.response.end();
		}
	}

	// Requête inconnues
	else {
		request.response.statusCode = 404;
		request.response.end();
	}

}).listen(PORT);
logger.info('Serveur démarré sur le port ' + PORT);