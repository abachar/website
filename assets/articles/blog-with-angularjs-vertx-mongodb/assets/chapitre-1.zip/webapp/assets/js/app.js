var app = angular.module('app', []);

/**
 * Configure routes
 */
app.config(['$routeProvider', function($routeProvider) {

	$routeProvider.
		when('/post/:code', {templateUrl:'partials/post.html' , controller: detailPostController}).
		when('/'          , {templateUrl:'partials/posts.html', controller: listPostController}).
		otherwise({redirectTo:'/'});
}]);

/**
 *
 */
function listPostController($scope) {

	$scope.posts = [
		{code: 'vertx'    , title: 'Vert.x'   , date: new Date(2013, 1, 25), author: 'Abdelhakim Bachar', nbComments:2 , text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eu justo quam, gravida pharetra urna. Etiam...'},
		{code: 'angularjs', title: 'AngularJS', date: new Date(2012, 10, 2), author: 'Abdelhakim Bachar', nbComments:12, text: 'Vivamus eros neque, elementum non venenatis pharetra, volutpat et ante. Pellentesque et orci turpis, nec vulputate orci. In hac...'},
		{code: 'jquery'   , title: 'jQuery'   , date: new Date(2010, 5, 10), author: 'Abdelhakim Bachar', nbComments:20, text: 'Integer eros arcu, sodales ut euismod in, hendrerit vel magna. Quisque condimentum, libero vel ultricies...'},
	];
}

/**
 *
 */
function detailPostController($scope) {

	$scope.post = {
		code  : 'vertx'    , 
		title : 'Vert.x'   , 
		date  : new Date(2013, 1, 25), 
		author: 'Abdelhakim Bachar', 
		text  : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eu justo quam, gravida pharetra urna. Etiam lacinia massa quis nisi pharetra id iaculis arcu gravida. Phasellus a odio quam, sed tincidunt metus. Duis hendrerit sodales sapien eget cursus. Suspendisse potenti. Cras orci libero, luctus in sodales ac, sagittis eu lectus. Maecenas commodo libero non leo bibendum lobortis. Nunc tristique scelerisque ligula eget venenatis. Etiam sed ante nisl. Sed elit nunc, dictum vel convallis et, vulputate ac neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. '
	};

	$scope.comments = [
		{date: new Date(2013, 1, 25), author: 'Abdelhakim Bachar', subject: 'Lorem ipsum dolor sit amet', text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eu justo quam, gravida pharetra urna.'},
		{date: new Date(2013, 1, 26), author: 'Ilyas', subject: 'Vivamus eros neque', text: 'Vivamus eros neque, elementum non venenatis pharetra, volutpat et ante. Pellentesque et orci turpis, nec vulputate orci.'}
	];
}