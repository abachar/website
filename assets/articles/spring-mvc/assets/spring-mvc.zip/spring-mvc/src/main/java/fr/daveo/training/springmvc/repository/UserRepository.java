package fr.daveo.training.springmvc.repository;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import fr.daveo.training.springmvc.domain.User;

@Repository
public class UserRepository {
	
	private Map<String, User> users = new Hashtable<String, User>();

	public User findByUsername(String username) {
		for (String id : users.keySet()) {
			if (username.equals(users.get(id).getUsername())) {
				return users.get(id);
			}
		}
		
		return null;
	}

	public User save(User user) {
		users.put(user.getId(), user);
		return user;
	}

	public List<User> findAll() {
		return new ArrayList<User>(users.values());
	}

	public void delete(User user) {
		users.remove(user.getId());
	}

	public User get(String userId) {
		return users.get(userId);
	}
}
