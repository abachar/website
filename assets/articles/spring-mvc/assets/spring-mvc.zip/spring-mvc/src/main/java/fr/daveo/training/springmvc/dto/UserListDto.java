package fr.daveo.training.springmvc.dto;

import java.util.List;

import fr.daveo.training.springmvc.domain.User;

public class UserListDto {

	private List<User> users;

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}
}
