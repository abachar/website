package fr.daveo.training.springmvc.repository;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import fr.daveo.training.springmvc.domain.Role;

@Repository
public class RoleRepository {

	private Map<String, Role> roles = new Hashtable<String, Role>();

	public Role get(String id) {
		return roles.get(id);
	}

	public void save(Role role) {
		roles.put(role.getId(), role);
	}

	public void delete(Role role) {
		roles.remove(role.getId());
	}

	public List<Role> getAll() {
		return new ArrayList<Role>(roles.values());
	}
}
