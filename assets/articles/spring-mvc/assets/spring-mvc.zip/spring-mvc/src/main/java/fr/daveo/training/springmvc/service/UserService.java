package fr.daveo.training.springmvc.service;

import java.util.List;
import java.util.UUID;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.daveo.training.springmvc.domain.Role;
import fr.daveo.training.springmvc.domain.User;
import fr.daveo.training.springmvc.repository.RoleRepository;
import fr.daveo.training.springmvc.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RoleRepository roleRepository;

	@PostConstruct
	public void init() {

		// Roles
		Role adminRole = new Role("admin");
		roleRepository.save(adminRole);

		Role guestRole = new Role("guest");
		roleRepository.save(guestRole);

		// Users
		userRepository.save(new User("Super", "Administrator", "sa", "root", adminRole));
		userRepository.save(new User("John", "Smith", "sjohn", "passwd", guestRole));
		userRepository.save(new User("Jane", "Adams", "ajane", "passwd", guestRole));
		userRepository.save(new User("Corline", "Bauduin", "cbauduin", "passwd", guestRole));
		userRepository.save(new User("Selin", "Vardar", "svarda", "passwd", guestRole));
		userRepository.save(new User("Abdelhakim", "Bachar", "abachar", "passwd", guestRole));
		userRepository.save(new User("Marine", "Dauguet", "mdauguet", "passwd", guestRole));
		userRepository.save(new User("Romain", "Meric", "rmeric", "passwd", guestRole));
		userRepository.save(new User("Mathieu", "Gougeon", "mgougeon", "passwd", guestRole));
		userRepository.save(new User("Arnaud", "Menjucq", "amenjucq", "passwd", guestRole));
		userRepository.save(new User("Mailan", "Masson", "mmasson", "passwd", guestRole));
		userRepository.save(new User("Mathieu", "Delin", "mdelin", "passwd", guestRole));
		userRepository.save(new User("Babacar", "Diaw", "bdiaw", "passwd", guestRole));
		userRepository.save(new User("Zouhair", "Jemai", "zjemai", "passwd", guestRole));
		userRepository.save(new User("Brahim", "Saidane", "bsaidane", "passwd", guestRole));

	}

	public List<User> getAll() {
		return userRepository.findAll();
	}

	public User get(String userId) {
		return userRepository.get(userId);
	}

	public User create(User user) {
		user.setId(UUID.randomUUID().toString());
		user.setRole(roleRepository.get(user.getId()));
		return userRepository.save(user);
	}

	public User update(User user) {
		User existingUser = userRepository.get(user.getId());

		if (existingUser == null) {
			return null;
		}

		existingUser.setFirstName(user.getFirstName());
		existingUser.setLastName(user.getLastName());
		existingUser.getRole().setRole(user.getRole().getRole());
		return userRepository.save(existingUser);
	}

	public Boolean delete(String userId) {
		User existingUser = userRepository.get(userId);

		if (existingUser == null) {
			return false;
		}

		userRepository.delete(existingUser);
		return true;
	}

	public List<Role> getAllRoles() {
		return roleRepository.getAll();
	}

}
