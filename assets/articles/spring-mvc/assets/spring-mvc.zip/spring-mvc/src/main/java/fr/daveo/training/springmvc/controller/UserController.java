package fr.daveo.training.springmvc.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import fr.daveo.training.springmvc.domain.User;
import fr.daveo.training.springmvc.service.UserService;

@Controller
@RequestMapping("/users")
public class UserController {

	@Autowired
	private UserService userService;

	@RequestMapping(method = RequestMethod.GET)
	public String list(Model model) {

		List<User> users = userService.getAll();
		model.addAttribute("users", users);
		return "users/index";
	}

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public String create(Model model) {
		model.addAttribute("user", new User());
		model.addAttribute("roles", userService.getAllRoles());
		return "users/create";
	}

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public String postCreate(@Valid User user, BindingResult result, Model model) {

		if (result.hasErrors()) {
			model.addAttribute("roles", userService.getAllRoles());
			return "users/create";
		}

		userService.create(user);
		return "redirect:/users";
	}

	@RequestMapping(value = "/update/{userId}", method = RequestMethod.GET)
	public String update(@PathVariable String userId, Model model) {
		model.addAttribute("user", userService.get(userId));
		model.addAttribute("roles", userService.getAllRoles());
		return "users/update";
	}

	@RequestMapping(value = "/update/{userId}", method = RequestMethod.POST)
	public String postUpdate(@Valid User user, BindingResult result, Model model, @PathVariable String userId) {

		if (result.hasErrors()) {
			model.addAttribute("roles", userService.getAllRoles());
			return "users/update";
		}

		user.setId(userId);
		userService.update(user);
		return "redirect:/users";
	}

	@RequestMapping(value = "/delete/{userId}")
	public String delete(@PathVariable String userId) {
		userService.delete(userId);
		return "redirect:/users";
	}

	@RequestMapping(value = "/json/{userId}")
	public @ResponseBody
	User getJSON(@PathVariable String userId) {
		return userService.get(userId);
	}
}
